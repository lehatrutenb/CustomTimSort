import timsort
arr = [2, 1, 3, 5, 3, 7, 6, 8, 6, 2, 1]
print(timsort.timsort(arr))
print(arr)
